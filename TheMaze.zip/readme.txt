TheMaze
=======

2D multiplayer game implemented in Java as school project @ FIT BUT

Team members
------------
Marcel Fiala (xfiala47@stud.fit.vutbr.cz)
Jaroslav Kubik (xkubik25@stud.fit.vutbr.cz)

Assignment
----------
https://wis.fit.vutbr.cz/FIT/st/cwk.php?title=IJA:Zad%E1n%ED_projektu&csid=548836&id=9362
https://wis.fit.vutbr.cz/FIT/st/cwk.php?title=IJA:Pokyny_k_projektu&csid=548836&id=9362
